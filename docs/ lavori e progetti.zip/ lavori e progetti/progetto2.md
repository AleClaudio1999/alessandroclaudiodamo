+++
title = "Analisi di Logseq"
draft = false

+++

### Introduzione su Logseq

Logseq è una piattaforma per la gestione della propria conoscenza

attraverso la gestione di un database di file di testo (qui chiamati

singolarmente pagine) e possibili allegati, con inoltre la

possibilità di collegare e relazionare pagine e quindi concetti tra

di loro; facendo ciò si crea il cosiddetto grafo di conoscenza, che

permette di visualizzare al meglio i concetti e le loro relazioni.

Inoltre, possiamo utilizzare i file Markdown o la modalità org

esistenti per modificare, scrivere e salvare semplicemente eventuali

nuove note.

Logseq non è il primo tool a fare tutto questo, ma a differenza dei

concorrenti (come i più famosi Roamresearch e Obsidian) è del tutto

gratuito e si concentra su privacy, longevità e user control,

possibile grazie alla sua natura open source.

Ufficialmente il programma è ancora in beta, e al momento della

stesura è nella sua versione stable 0.8.2.

Il programma è disponibile per Windows, Mac e Linux, ma è

addirittura disponibile la web app funzionante direttamente da

browser.

\-----------

Language code

files --------------------------------------------------------------------

blank comment

\-----------

ClojureScript 45166

249 5824 1465

ClojureC 8316

12 393 65

CSS 5289

31 1116 45

JavaScript 709

Clojure 69

6 4 97 7 40

1

\-----------

SUM: 59549

\--------------------------------------------------------------------

302 7437 1616

### Superamento dei criteri di scelta del progetto

Scaricando il sorgente da Github (https://github.com/logseq/logseq)

e grazie al tool gratuito cloc (https://github.com/AlDanial/cloc) ho

contato il numero di LOC del programma affinché superassero le 50K

LOC previste dalla consegna: le LOC sono risultate 59549 cosi

suddivise.

\--------------------------------------------------------------------

\--------------------------------------------------------------------

\-----------

### Introduzione alla analisi del processo di produzioneLogseq è un progetto open source Logseq con licenza AGPL-3.0

sviluppato dall'ononimo team composto da 10 persone che lavorano in

remoto, da diversi posti del mondo e con orari asincroni.

Per analizzare al meglio il processo di produzione di Logseq,

partiremo dalla sua attuale release e cercheremo di capire da dove

nascono e come vengono sviluppate e realizzate le prossime feature.

Daremo un occhiata anche l'ambito finanziario: come il team si

finanzia e di essa sia una caratteristica che influisce sui progetti

a lungo termine.

Guarderemo il ruolo della community all'interno del progetto, e di

come essa collabora con il team sia per lo sviluppo di plugin sia

per il report di problemi e bug.

Controlleremo l'architettura del programma, come le nuove feature si

interfacciano con il programma e di come essa si sia evoluta nel

tempo.

Infine concluderemo guardando la presentazione del team, i loro

valori, la loro filosofia lavorativa con particolare enfasi sulla

loro metodologia di comunicazione, provando a fare eventuali

correlazioni con l'XP programming.

### Da dove nascono le nuove feature?

Per ideazione di nuove feature il team di Logseq si rivolge molto

spesso alla community, attraverso un proprio blog di discussione

(https://discuss.logseq.com ) dove in una sezione chiamata "Feature

request" qualsiasi utente registrato gratuitamente può effettuare

una richiesta per aggiungere una nuova feature all'interno del

programma attraverso un post visibile a tutti.

Con una soluzione in stile Reddit, il post può essere votato e può

cosi risaltare agli occhi dei main developer che in base al risalto

del post, prioritizzano lo sviluppo di una feature rispetto ad

un'altra.

Qui per esempio (https://discuss.logseq.com/t/headings-where-they-

at/391) un utente scrive un post per chiedere che vengano aggiunti

gli Headings (semplificando sono scritte più grandi). Il post ha

avuto un buon risalto sia per numero di commenti che voti, e nel

giro di 5 mesi la meccanica è stata inserita all'interno del

programma.

Anche la funzionalità di nuove richieste di Github è attiva: in

questo caso però queste vengono automaticamente reindirizzate anche

sul blog come post, per riuscire a captare meglio quanta gente

sarebbe interessata a quella eventuale feature e quindi che tipo di

priorità darle usando il sistema di voti che Github non ha.

Come si vede chiaramente in questo post (https://discuss.logseq.com/

t/customizable-keyboard-shortcuts/146) un utente ha sollecitato gli

sviluppatori ad inserire una meccanica di personalizzazione delle

shortcuts da tastiera, nonostante la richiesta fosse inizialmente

stata formalizzata su Github (https://github.com/logseq/logseq/

issues/553).Oltre alle idee della community, il team di sviluppo concepisce

anche autonomamente le proprie feature: questo si intravede

immediatamente perchè moltissime delle feature pianificate o

attualmente in elaborazione non hanno una corrispondenza ne sul Blog

ne sul Github, e poi perché specialmente sul lungo termine il team

ha una idea ben precisa per finanziarsi ancora di più, come vedremo

più tardi.

In generale quindi il progetto è in parte guidato dalla community,

specie per piccole feature ma per introduzioni più grosse o a lungo

termine il progetto è indirizzato principalmente dal Team di

sviluppo.

### Dalle idee alla realizzazione

Le idee o le feature (che come abbiamo visto provengono sia dalla

community che dal team) devono quindi essere definite per bene prima

di essere realizzate: per fare ciò il team usa il metodo delle

"Cards".

Una "Card" è una rappresentazione visiva di un oggetto di lavoro che

può contenere informazioni preziose sull'attività e sul suo stato,

come un riepilogo dell'incarico, persona responsabile, scadenze; per

il team rappresenta una feature o una idea da sviluppare.

Analizzando le "Card" del team di Logseq nel dettaglio, essendo

prevalentemente lavori mediamente piccoli risultano molto minimali e

con poche informazioni.

Solitamente si trova al massimo qualche commento e qualche tag,

mentre per i lavori un po' più grandi si trovano check-list con una

lista da compiti da eseguire per dichiarare completato il lavoro.

Nessun accenno invece a test definiti in partenza da superare, che o

non sono definiti in partenza o non visibili pubblicamente, ad ogni

modo è una questione di relativa importanza poiché il lavoro

comunque subisce sempre una seconda revisione da altra persona del

team come vedremo più avanti.

Per visualizzare al meglio lo stato dei lavori il team distribuisce

le "Cards" in una tabella Kanban, che è uno strumento visivo

intelligente che offre una panoramica dello stato attuale del

lavoro, in questo caso è suddivisa in 4 colonne con To-Do, Doing,

Done, Long Term che si trova qui https://trello.com/b/8txSM12G/

logseq-roadmap.

Quando una "Card" è realizzata viene messa nella colonna To-Do, in

questa colonna i componenti del team possono visualizzare e

scegliere un lavoro alla quale legarsi.

Quando un elemento del team si prende carico di un lavoro la sposta

nella colonna Doing, per informare e aggiornare tutto il team sulla

sua scelta e sulla sua nuova distribuzione del lavoro.

Qua viene generato un branch separato rispetto dal branch master

principale, dove il o i developer possono lavorare sulla nuova

feature.Quando il lavoro è terminato, la "Card" entra nella sezione di Code

Review, dove l'elaborato deve ricevere obbligatoriamente un

controllo da un'altro sviluppatore. In questo settore c'è un un

attributo chiamato List Limit: quando ci sono troppe carte in questa

colonna viene indicato al team che ogni componente che si libera

deve preferire eseguire una review ad una "Cards" piuttosto che

prendere un nuovo lavoro.

Una volta che il lavoro è stato testato correttamente, la carta

viene spostata sulla colonna Done, e il lavoro viene riammesso al

branch principale e rilasciato in primis nella versione Early Access

e poi nella versione ufficiale.

Un trattamento a parte sta venendo dedicata alla feature

"whiteboard", che punta ad essere una feature complessa ed

esclusiva: a lei è stata istituita una tabella Kanban apposita su

GitHub.

(https://github.com/orgs/logseq/projects/2/views/1)

La tabella Kanban del team con la distribuzione del lavoro e le sue

"Cards" si trovava prima su Github ( https://github.com/logseq/

logseq/projects/1 ma dismessa da fine 2020) e si trova ora su Trello

(https://trello.com/b/8txSM12G/logseq-roadmap)

### Bug

Anche per la questione Bug e problemi ci si affaccia moltissimo alla

community: i developer prediligono la sezione "Issues" di Github

(https://github.com/logseq/logseq/issues) per la richiesta di

qualche fix o bug fix.

Per la risoluzione, i developer o la community può lavorare sul

codice per poi richiedere il pull sul master branch, solitamente a

occuparsene sono singoli membri del team o sviluppatori.

Può anche essere usato il blog (che ha una sua sezione dedicata) e

gli sviluppatori sono disponibili anche nei DM e nei canali Discord

(https://discuss.logseq.com/t/please-post-bug-reports-to-github-if-

you-can/3503)

### Ambito economico del progetto

Logseq è un progetto open source con licenza AGPL-3.0: quindi è

ovviamente gratuito. Per supportare gli sviluppatori e componenti

del team però è possibile donare una tantum o ricorrentemente

attraverso la piattaforma open collective (https://

opencollective.com/logseq). In base all'ammontare donato è possibile

ottenere le versioni early access dei nuovi aggiornamenti e vantaggi

quali badge su discord e sponsor sul sito e pagina Github.

Il progetto è nato dalla mente del developer Tienson e finanziato

dai Angel investors: attualmente conta 10 developer a lavoro sul

team, con un pagamento annuale oltre che una percentuale di equitàsul progetto.

Non solo, il team è attualmente anche finanziato da grandi

investitori coem quelli di Airbnb, Instagram, Quora, Neuralink,

SpaceX, Facebook, Stripe, GitHub, Shopify, Uber, AngelList, ecc.

ttps://adventurous-ragdoll-1e0.notion.site/Design-Frontend-Engineer-

d5b58061f02a42118b3ecdda5a9774ca

Però per il team, l'attuale reddito sembra non essere sufficiente,

infatti tra gli obbiettivi c'è quello di aumentare la monetizzazione

attraverso nuovi metodi.

Logseq infatti ha intenzione di creare nel lungo periodo una sua

versione Pro a pagamento con vantaggi tra cui la possibilità di

avere un database synchato su tutti i device caricando il database

su un server di loro proprietà (stile Roamresearch), ma anche di

feature nuove esclusive per chi vuole continuare ad usare un

database locale.

Quindi in futuro i progetti si suddivideranno con Logseq Pro (closed

source e a pagamento) ma continueranno anche a mantenere ed

aggiornare la versione standard e attuale open Source (https://

docs.logseq.com/#/page/faq)

https://discuss.logseq.com/t/what-is-logseqs-business-model/389/3

### Community

Precedentemente abbiamo visto come la community giochi un ruolo

importante sia per l'ideazione di nuove possibili feature ma anche

quello riportare bug o problemi di ogni sorta.

Per quanto riguarda il mero sviluppo invece, la community può

contribuire attraverso lo sviluppo del programma in se ma soltanto

attraverso la creazione di plugin. Ovviamente nessuno vieta la

possibilità di agire direttamente sul programma, essendo di sua

natura open source, ma la master branch vuole rimanere fedelmente in

mano al team.

Tornando ai plugin, questi devono soddisfare due requisiti:

intervenire con assoluta privacy e sicurezza sui dati dell'utente e

ovviamente non fare qualcosa che fa già il programma out of the box.

Per registrare il proprio lavoro, è sufficiente che il che lo

sviluppatore crei un fork e poi una richiesta del pull del progetto

Marketplace packages su Github(https://github.com/logseq/

marketplace), questo lo rende non solo disponibile ma addirittura

esposto sul marketplace totalmente gratuito all'interno del

programma stesso.

Oltre a questo, la community collabora anche per quanto riguarda la

stesura della documentazione interna e esterna, incentivati dal team

dal team stesso.

Per la documentazione interna si intendono i tutorial e le linee

guida all'interno del programma: per fare questo basta effettuare la

solita meccanica di fork e pull da github.

Per quanto riguarda invece la documentazione esterna, è sufficiente

interagire sul blog o fare contenuti su piattaforme esterne.https://discuss.logseq.com/t/how-to-contribute-to-logseqs-

documentation/7761/6

https://discuss.logseq.com/t/how-to-contribute-to-logseqs-

documentation/7761

### Architettura

Inizialmente l'architettura del programma era molto differente, non

era modulata e ogni nuova feature o componente interagiva

direttamente sul datascript, il che presentava un grossi limiti allo

sviluppo per via della granularità dei moduli troppo grossolana, e

in più il codice in se iniziava a presentare dei pesanti ostacoli.

Per questo il programma è stato sottoposto ad un pesante

refactoring: Attualmente Logseq è composto da due componenti, Logseq

plugin core e Logseq Core.

I plugin della community si interfacciano con il Logseq Plugin core,

mentre quest'ultimo invece si interfaccia al logseq core, che è il

motore dell'applicazione, che permette di fare tutte le operazioni

di editing e di spostamento dei blocchi.

Gli official Plugins invece, che si interfacciano direttamente sul

Logseq Core, sono i componenti ufficiali dell'applicazione

sviluppati dal team che non fanno parte del Logseq Core, come per

esempio il motore di ricerca o i temi basici.

Questo tipo di architettura permette non solo di aggiungere la

possibilità di usare i Plugin della community in totale sicurezza,

ma anche per gli stessi developer ufficiali di lavorare per

componenti, il che permette di isolare meglio gli errori, specie per

le feature in sviluppo nuove.

https://docs.logseq.com/#/page/The%20Refactoring%20Of%20Logseq

\###Valori, metodologia di lavoro e correlazioni con l'XP

Andando sulla pagina (https://adventurous-ragdoll-1e0.notion.site/

Who-is-Logseq-2ccab355138e4caaaa01ef581f9335eb)si trova una pagina

introduttiva che descrive la filosofia, gli obbiettivi e il modo di

lavorare del team Logseq.

Nonostante non sia scritto chiaramente l'adesione alla metodologia

dell'extreme programming, si possono trovare numerose analogie con

essa.

Per quanta riguarda la comunicazione per esempio sul sito viene

scritto che: "Noi condividiamo apertamente, ampiamente e

deliberatamente e siamo straordinariamente sinceri gli uni con gli

altri".

Vengono anche aggiunti dei dettagli sul tipo della comunicazione del

team, che avviene principalmente in maniera asincrona essendo un

team che lavora da remoto e con elementi umani provenienti da più

parti del mondo e con fusi diversi, il che rende anche molto costose

le comunicazioni dal vivo

Inoltre secondo il team questo modo di comunicare asincrono, fatto

di note e "post it" permette loro di andare dritto al punto delle

idee più velocemente.Per quanto riguarda la comunicazione, tutti possono parlare con

tutti, persino l'ultimo dei programmatori con il cliente, proprio

come nel XP; è sufficiente controllare il loro forum (https://

discuss.logseq.com) o entrare nel loro server Discord per vedere le

iterazioni di tutti e 10 i membri del team con i vari utenti.

Questo significa avere numerosi, continui e immediati feedback non

solo con la community ma anche all'interno del team stesso, e come

nell'XP esso deve essere messo in pratica e realizzato con la stessa

rapidità.

Un altro valore è il coraggio e la libertà di sperimentazione: "Il

rischio è direttamente proporzionale all'impatto"

Come per l'XP serve coraggio nel prendere decisioni importanti ma

anche nel riconoscere che una decisione presa in precedenza si è

rivelata non adeguata.

La tipologia di ritmo lavorativo è molto flessibile dato il sistema

di lavoro asincrono, oltre alle innumerevoli agevolazioni come i 14

giorni di vacanze pagate, bonus per l'acquisto di materiale dedicato

allo studio, soldi aggiuntivi da spendere per salute e palestra

oltre al piano di assicurazione medica.

Non si conosce di preciso le ore lavorative a settimana del team, ma

uno dei motti di Logseq è "è una maratona non uno sprint", quindi si

presuppone che non siano molto distanti dalle 40 ore lavorative a

settimana previste dal XP programming.

In più il team di Logseq si dichiara "Action Oriented", ovvero senza

paura di sbagliare, con sviluppi molto pratici e in grado di

sistemare gli input velocemente, in totale sinergia con la filosofia

dell'XP, vista anche la prontezza e il numero di release che fanno:

piccole ma frequenti.

Andando su Github per esempio possiamo vedere che l'ultima versione

(0.8.2) è uscita 6 giorni fa, quella prima la (0.8.1) 12 giorni fa,

la terzultima la (0.8.0) 20 giorni fa. Guardando i changelog si

capisce che sono aggiornamenti non sono aggiornamenti grossi ma

prevalentemente bug fix.

(https://github.com/logseq/logseq/releases)

Anche la struttura lavorativa e l'organizzazione del lavoro che

abbiamo già osservato è molto simile a quella usata per l'XP, ovvero

oggetti di lavoro organizzati e presentati come "cards" e

distribuiti su una tabella Kanban.

Per quanto riguarda la frequenza di refactoring:

Logseq ne ha affrontato uno in particolare, molto pesante che è

risultato in una architettura più pulita e robusta come abbiamo già

documentato prima.

Nonostante questo ancora adesso il team si sta forzando nel

migliorare le performance e il codice il più possibile; il codice

infatti è ancora adesso è sottoposto a cambiamenti e revisioni,

soprattutto per il fatto di essere ancora in beta, come ben si vede

in questa specifica "Cards" nella attuale tabella Kanban, dove gli

obbiettivi sono quelli migliorare il caricamento di pagine moltograndi, la reattività delle queries, l'uso della memoria per oltre

10k note e la scrittura di pagine particolarmente lunghe (https://

trello.com/c/68pohS4z/1125-performance-improvement)

Per Logseq è infatti fondamentale che il core e tutto il resto non

solo non siano soggetti a bug, ma anche che performance siano sempre

di buon livello.

Il core di Logseq infatti usa tanta manipolazione attorno a file e

byte, sopratutto di raw string e a dover gestire il loro cambio di

posizione, oltre a questo deve fare i conti con Unicode characters:

questo in breve significa che se non viene migliorato il codice

progressivamente le performance possono risultare un grosso limite

per il numero di pagine che Logseq può creare e gestire, e alla

lunga può rappresentare un grosso ostacolo per chi crea per esempio

pagine giornalmente.

https://docs.logseq.com/#/page/The%20Refactoring%20Of%20Logseq

Non c'è invece sicuramente una componente dell'XP, ovvero il pair

programming, dove due programmatori lavorano insieme su una sola

workstation: risulta quasi impossibile fare ciò per un team che

lavora totalmente in remoto e con comunicazione prettamente

asincrona.

A dimostrazione di ciò, come abbiamo visto sulla tabella Kanban,

molto spesso a legarsi ad una singola "Cards" e quindi ad un lavoro

sono singoli componenti del team.
