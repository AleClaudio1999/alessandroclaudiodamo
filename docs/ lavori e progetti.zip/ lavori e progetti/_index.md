+++
draft = false
title = 'Lavori e progetti'

+++

Qui puoi vedere i miei lavori e progetti principali:

- [Cross-core interference - An Ubuntu and OpenEuler experience](/lavori/progetto1/)
- [Analisi di Logseq](/lavori/progetto2/)

